
    $(document).ready(function(){

             /* PAID */  
         $(".plan").click(function(){
           var uid = $(this).attr("uid");
           var universityname = $(this).attr("universityname");
           //var universityemail = $(this).attr("email");
           var universityemail = $(".email").val();     
           var amount = 2000;     
           var selectedplan = $(this).attr("plan");

           if (selectedplan == "startup") {
            //Start up plan amount   
            var amount = 2200000;
            var selectedplan = $(this).attr("plan");

           } else if (selectedplan == "prenmium") {

             var amount = 4400000;
             var selectedplan = $(this).attr("plan");

           } else if (selectedplan == "advanced") {

             var amount = 13400000;
             var selectedplan = $(this).attr("plan"); 

           }

           payWithPaystack(selectedplan, uid, amount, universityemail, universityname );
        });//Close Paid Plans

            /* ----END ----*/

                     /* FREE Button */  
         $(".freeplan ").click(function(){
           var uid = $(this).attr("uid");        
           var selectedplan = $(this).attr("plan");
            //alert(selectedplan)
                $.ajax({

                    url:"http://localhost:3000/universities/plan/" + uid,
                    method:"PUT",
                    data:{
                        "plan": selectedplan   
                    } ,
                    success: function (data) {
                    location.reload();  
                    }, error: function (data) {
                    alert("Oops, User plan could not be set");  
                    console.log(data)
                  }

                      });  

        });//Close Paid Plans

            /* ----END ----*/


            /* TRIAL PERIOD */
           $(".trial").click(function(){
           var selectedplan = $(this).attr("plan");
           var uid = $(this).attr("uid");
           var amount = 2000;
           var email = "davies.c.i@studyinbudapest.com";
           var studentname = "Davies iyiegbu";    
          // alert(selectedplan);
           location.reload();
           $.ajax({

                    url:"http://localhost:3000/universities/plan/" + uid,
                    method:"PUT",
                    data:{
                        "plan": selectedplan
                    } ,
                    success: function (data) {
                    console.log("User set to free")   
                    }, error: function (data) {
                    alert("Oops, User could not be set to free");    
                    console.log(data)
                }

            }); 

            });//Close Trial  


    });//Close Document.Ready

    //Paystack
    function payWithPaystack(selectedplan , uid, amount, universityemail, universityname){
        var email = universityemail.toString();
        var studentname = universityname;
        var sub = new Date().toISOString();
        var handler = PaystackPop.setup({
          key: 'pk_test_85109bc425178e6f6c00d8a90f871ebf4adf8c62',
          email: email,
          amount: amount,
          metadata: {
             custom_fields: [
                {
                    display_name: "University Name", //use this to pass in any other fields from a form 
                    variable_name: universityname,
                    value: universityname
                }
             ]
          },
          callback: function(response){
          // alert('success. transaction ref is ' + response.reference);
              
          //swal("Thank you for the payment!", "Start recuiting international students in the most amazing way.", "success")
          $.ajax({
                url:"http://localhost:3000/universities/plan/" + uid,
                method:"PUT",
                data:{
                    "plan": selectedplan,
                    "sub": sub
                } ,
                success: function (data) {
                var date = new Date().toDateString();
                if (amount == 2200000){
                 amount = 49;//Eur    
                } else if (amount == 4400000){
                 amount = 99;//Eur    
                } else if (amount == 13400000){
                 amount = 299;//Eur     
                }    
               $.ajax({

                    url:"http://localhost:3000/invoice",
                    method:"POST",
                    data:{
                        "plan": selectedplan,
                        "universityname": universityname,
                        "universityemail": universityemail,
                        "amount": amount,
                        "date": date
                    } ,
                    success: function (data) {
                    console.log("Invoiced succesfully")   
                    }, error: function (data) {
                    alert("Could not invoice");    
                    console.log(data)
                }

              });      
                           
            swal({   
            title: "Thank you for the payment!",   
            text: "Start recuiting international students in the most amazing way.",   
            type: "success",   
            showCancelButton: false,   
            confirmButtonColor: "#00CC66",   
            confirmButtonText: "OK",   
            cancelButtonText: "Close",   
            closeOnConfirm: true, // revisit if error
            allowEscapeKey: false,    
            closeOnCancel: false 
        }, function(isConfirm){   
            if (isConfirm) { 
             location.reload()    
              //window.location.href = "#/university/account/" + uid;
               
            } else {     
                swal("User Guide", "You need to go to your dashbaord to start recruiting", "success");
               
            } 
        }); //End swal   
                }, error: function (data) {
                alert("Oops, User could not be set to free");    
                console.log(data)
            }

        });  

          },
          onClose: function(){
              //alert('window closed');

          }
        });
        handler.openIframe();
      }// End Paystack



    //Paypal STARTUP plan
    paypal.Button.render({

                env: 'sandbox', // sandbox | production

                // PayPal Client IDs - replace with your own
                // Create a PayPal app: https://developer.paypal.com/developer/applications/create
        style: {
                label: 'pay',
                fundingicons: true, // optional
                branding: true, // optional
                size:  'responsive', // small | medium | large | responsive
                shape: 'rect',   // pill | rect
                color: 'blue'   // gold | blue | silve | black
            },


                client: {
                    sandbox:'AWBDYt0cGKhC2iKGicyfZUqYdJgyDqwcOtmYW-n8Q3mWNJMCIlkJeLjgQEec3GAQ8E6Zvc1TuJD-S5-l',
                    production: 'AaE3O1rI-3ewJCAyJE4wEyucEqncH7L1SaqmK3hhGHnfG3PW_qFVU1ZbtF03Sq875f2ydgKf55pbFUgP'
                },

                commit: true, // Show a 'Pay Now' button

                payment: function(data,actions) {
                    // Set up the payment here

                     // Make a call to the REST api to create the payment
                    return actions.payment.create({
                        payment: {
                            transactions: [
                                {
                                    amount: { total: '49.00', currency: 'EUR' }
                                }
                            ]
                        }
                    });

                },

                onAuthorize: function(data, actions) {
                    // Execute the payment here
                    // Make a call to the REST api to execute the payment
                    return actions.payment.execute().then(function() {
                    //window.alert('Payment Complete!'); 
           var uid = $("#paypal-button").attr("uid");
           var universityname = $("#paypal-button").attr("universityname");
           var universityemail = $("#paypal-button").attr("email");
           var sub = new Date().toISOString();                
           //var universityemail = $(".email").val();     
           var amount = 49;     
           var selectedplan = $("#paypal-button").attr("plan");        
                $.ajax({
                url:"http://localhost:3000/universities/plan/" + uid,
                method:"PUT",
                data:{
                    "plan": selectedplan,
                    "sub":sub
                } ,
                success: function (data) {
                //Invoice    
                var date = new Date().toDateString();    
               $.ajax({

                    url:"http://localhost:3000/invoice",
                    method:"POST",
                    data:{
                        "plan": selectedplan,
                        "universityname": universityname,
                        "universityemail": universityemail,
                        "amount": amount,
                        "date": date
                    } ,
                    success: function (data) {
                    console.log("Invoiced succesfully")   
                    }, error: function (data) {
                    alert("Could not invoice");    
                    console.log(data)
                }

              });      
                           
            swal({   
            title: "Thank you for the payment!",   
            text: "Start recuiting international students in the most amazing way.",   
            type: "success",   
            showCancelButton: false,   
            confirmButtonColor: "#00CC66",   
            confirmButtonText: "OK",   
            cancelButtonText: "Close",   
            closeOnConfirm: true, // revisit if error
            allowEscapeKey: false,    
            closeOnCancel: false 
        }, function(isConfirm){   
            if (isConfirm) { 
             location.reload()    
              //window.location.href = "#/university/account/" + uid;
               
            } else {     
                swal("User Guide", "You need to go to your dashbaord to start recruiting", "success");
               
            } 
        }); //End swal   
                }, error: function (data) {
                alert("Oops, User could not be set to free");    
                console.log(data)
            }

        }); 
                       
                    });//Then sucess
               }

            }, '#paypal-button');//End Paypal







    //Paypal Premium University
    paypal.Button.render({

                env: 'sandbox', // sandbox | production


        style: {
                label: 'pay',
                fundingicons: true, // optional
                branding: true, // optional
                size:  'responsive', // small | medium | large | responsive
                shape: 'rect',   // pill | rect
                color: 'blue'   // gold | blue | silve | black
            },

                // PayPal Client IDs - replace with your own
                // Create a PayPal app: https://developer.paypal.com/developer/applications/create
                client: {
                    sandbox:'AWBDYt0cGKhC2iKGicyfZUqYdJgyDqwcOtmYW-n8Q3mWNJMCIlkJeLjgQEec3GAQ8E6Zvc1TuJD-S5-l',
                    production: 'AaE3O1rI-3ewJCAyJE4wEyucEqncH7L1SaqmK3hhGHnfG3PW_qFVU1ZbtF03Sq875f2ydgKf55pbFUgP'
                },

                // Show the buyer a 'Pay Now' button in the checkout flow

                commit: true, // Show a 'Pay Now' button

                payment: function(data,actions) {
                    // Set up the payment here

                     // Make a call to the REST api to create the payment
                    return actions.payment.create({
                        payment: {
                            transactions: [
                                {
                                    amount: { total: '99.00', currency: 'EUR' }
                                }
                            ]
                        }
                    });

                },

                onAuthorize: function(data, actions) {
                    // Execute the payment here
                    // Make a call to the REST api to execute the payment
                    return actions.payment.execute().then(function() {
           var uid = $("#paypal-button-premium-uni-plan").attr("uid");
           var universityname = $("#paypal-button-premium-uni-plan").attr("universityname");
           var universityemail = $("#paypal-button-premium-uni-plan").attr("email");
           var sub = new Date().toISOString();                
           //var universityemail = $(".email").val();     
           var amount = 99;     
           var selectedplan = $("#paypal-button-premium-uni-plan").attr("plan");        
                $.ajax({
                url:"http://localhost:3000/universities/plan/" + uid,
                method:"PUT",
                data:{
                    "plan": selectedplan,
                    "sub": sub
                } ,
                success: function (data) {
                //Invoice    
                var date = new Date().toDateString();    
               $.ajax({

                    url:"http://localhost:3000/invoice",
                    method:"POST",
                    data:{
                        "plan": selectedplan,
                        "universityname": universityname,
                        "universityemail": universityemail,
                        "amount": amount,
                        "date": date
                    } ,
                    success: function (data) {
                    console.log("Invoiced succesfully")   
                    }, error: function (data) {
                    alert("Could not invoice");    
                    console.log(data)
                }

              });      
                           
            swal({   
            title: "Thank you for the payment!",   
            text: "Start recuiting international students in the most amazing way.",   
            type: "success",   
            showCancelButton: false,   
            confirmButtonColor: "#00CC66",   
            confirmButtonText: "OK",   
            cancelButtonText: "Close",   
            closeOnConfirm: true, // revisit if error
            allowEscapeKey: false,    
            closeOnCancel: false 
        }, function(isConfirm){   
            if (isConfirm) { 
             location.reload()    
              //window.location.href = "#/university/account/" + uid;
               
            } else {     
                swal("User Guide", "You need to go to your dashbaord to start recruiting", "success");
               
            } 
        }); //End swal   
                }, error: function (data) {
                alert("Oops, User could not be set to free");    
                console.log(data)
            }

        });
                    });
               }

            }, '#paypal-button-premium-uni-plan');//End Paypal



    //Advanced University
    paypal.Button.render({

                env: 'sandbox', // sandbox | production


        style: {
                label: 'pay',
                fundingicons: true, // optional
                branding: true, // optional
                size:  'responsive', // small | medium | large | responsive
                shape: 'rect',   // pill | rect
                color: 'blue'   // gold | blue | silve | black
            },

                // PayPal Client IDs - replace with your own
                // Create a PayPal app: https://developer.paypal.com/developer/applications/create
                client: {
                    sandbox:'AWBDYt0cGKhC2iKGicyfZUqYdJgyDqwcOtmYW-n8Q3mWNJMCIlkJeLjgQEec3GAQ8E6Zvc1TuJD-S5-l'
                    //production: 'AaE3O1rI-3ewJCAyJE4wEyucEqncH7L1SaqmK3hhGHnfG3PW_qFVU1ZbtF03Sq875f2ydgKf55pbFUgP'
                },

                // Show the buyer a 'Pay Now' button in the checkout flow

                commit: true, // Show a 'Pay Now' button

                payment: function(data,actions) {
                    // Set up the payment here

                     // Make a call to the REST api to create the payment
                    return actions.payment.create({
                        payment: {
                            transactions: [
                                {
                                    amount: { total: '299.00', currency: 'EUR' }
                                }
                            ]
                        }
                    });

                },

                onAuthorize: function(data, actions) {
                    // Execute the payment here
                    // Make a call to the REST api to execute the payment
                    return actions.payment.execute().then(function() {
           var uid = $("#paypal-button-advanced-uni-plan").attr("uid");
           var universityname = $("#paypal-button-advanced-uni-plan").attr("universityname");
           var universityemail = $("#paypal-button-advanced-uni-plan").attr("email");
           var sub = new Date().toISOString();                
           //var universityemail = $(".email").val();     
           var amount = 299;     
           var selectedplan = $("#paypal-button-advanced-uni-plan").attr("plan");        
                $.ajax({
                url:"http://localhost:3000/universities/plan/" + uid,
                method:"PUT",
                data:{
                    "plan": selectedplan,
                    "sub":sub
                } ,
                success: function (data) {
                //Invoice    
                var date = new Date().toDateString();    
               $.ajax({

                    url:"http://localhost:3000/invoice",
                    method:"POST",
                    data:{
                        "plan": selectedplan,
                        "universityname": universityname,
                        "universityemail": universityemail,
                        "amount": amount,
                        "date": date
                    } ,
                    success: function (data) {
                    console.log("Invoiced succesfully")   
                    }, error: function (data) {
                    alert("Could not invoice");    
                    console.log(data)
                }

              });      
                           
            swal({   
            title: "Thank you for the payment!",   
            text: "Start recuiting international students in the most amazing way.",   
            type: "success",   
            showCancelButton: false,   
            confirmButtonColor: "#00CC66",   
            confirmButtonText: "OK",   
            cancelButtonText: "Close",   
            closeOnConfirm: true, // revisit if error
            allowEscapeKey: false,    
            closeOnCancel: false 
        }, function(isConfirm){   
            if (isConfirm) { 
             location.reload()    
              //window.location.href = "#/university/account/" + uid;
               
            } else {     
                swal("User Guide", "You need to go to your dashbaord to start recruiting", "success");
               
            } 
        }); //End swal   
                }, error: function (data) {
                alert("Oops, User could not be set to free");    
                console.log(data)
            }

        });

                    });
               }

            }, '#paypal-button-advanced-uni-plan');//End Paypal

    // window.location.replace(window.location.pathname + window.location.search + window.location.hash);// does not create a history entry 
     //window.location.href = window.location.pathname + window.location.search + window.location.hash;// creates a history entry
     //window.location.reload(false); // If we needed to pull the document from//  the web-server again (such as where the document contents
    //  change dynamically) we would pass the argument as 'true'.
    //$(".plan").html(selectedplan);
    //alert (uid)