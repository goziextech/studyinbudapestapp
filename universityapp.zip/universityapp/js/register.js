$(document).ready(function(){
$(".register").on('click',function(e){
 e.preventDefault();    
 register();    
}) 

//validatePhone();

});

//value.match(/\d/g).length===10;
function validatePhone(){
    var phone = "234244444";
    var RE = /^[2-9]\d{2}[2-9]\d{2}\d{4}$/;
    if(!RE.test(phone))
    {
        alert("You have entered an invalid phone number");
        return false;
    }
    alert ("Valid Phone Number");
    return true;
}

// Register
function register() {  
var endpoint = "universities";
var firstname = $('#full-name-field').val().toLowerCase();
var fname = firstname.charAt(0).toUpperCase() + firstname.slice(1);    
var lastname = $('#last-name-field').val().toLowerCase();
var lname = lastname.charAt(0).toUpperCase() + lastname.slice(1);     
var eml = $('#email-field').val().toLowerCase();  
var ph = $('#phone-field').val().toLowerCase();
var universityname = $('#university-field').val().toLowerCase();    
var uni = universityname.charAt(0).toLocaleUpperCase() + universityname.slice(1); 
var countryval = $('#country-field').val().toLowerCase();    
var country = countryval.charAt(0).toUpperCase() + countryval.slice(1);
var p = $('#p').val();
var universityportal = $('#university-portal ').val().toLowerCase();   
var date = (new Date()).toString().split(' ').splice(1,3).join(' ');
var time = new Date();
var hours = time.getHours();
var minutes = time.getMinutes();
var seconds = time.getSeconds();
var timeofactivity = hours +":" + minutes    
var url = "http://localhost:3000/"+ endpoint;//universities
var uc = "http://localhost:3000/u/c";
var validurl = /^(https?|s?ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i;
var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;       
var testPhone = /^[2-9]\d{2}[2-9]\d{2}\d{4}$/i; // Retired
var validateurl = validurl.test(universityportal);
var validemail = testEmail.test(eml);
//var validphone = testPhone.test(ph);
var validphone = ph.match(/\d/g); //In use  
var validterms = $('#checkbox-signup').is(":checked");  
var minimump = p.length >= 8;
    
      
if ((validateurl) && (validemail) && (validterms) && (validphone) && (fname) && (lname) && (eml) && (ph) && (uni) && (p) && (!minimump) && (universityportal) && (country) ){
    
    //alert ("Its about to go down")
    
   //swal("Valid", "IS VALID", "success"); //Post from here 
       $.ajax({
        
            url:uc,
            method:"POST",
            data:{  
            "username": lname,    
            "email": eml    
            },
            success:function (data) {
            var newuser = (data.status) == "usernotfound";    
            if ((newuser)){    
              $(".usrem").hide();
                
               $.ajax({
        
            url:url,
            method:"POST",
            data:{
                
        "first_name":fname,
        "last_name": lname,        
        "email": eml,
        "username": eml,
        "password": p,
        "university": uni,
        "country": country,
        "city": "",
        "state": "",
        "phone": ph,
        "pd": "advanced",
        "trial": true,        
        "device": "",
        "about": "",
        "session": "not timeout",
        "activation": "notactivated",        
        "date_of_activity": date,
        "verification_status": "no",
        "image_url": "",
        "university_website": "",
        "application_portal": universityportal,
        "processed_students": [
            
        ],
        "rejected_students": [
            
        ],
        "admission_offers": [
    
        ],
        "courses": [
            
        ],
        "msg_txt": [
            
        ]
     
            } ,
            success: function (data) {
                  
           swal({   
            title: "Registration Successful!",   
            text: "We've sent you an email to verify your account.",   
            type: "success",   
            showCancelButton: true,   
            confirmButtonColor: "#00CC66",   
            confirmButtonText: "Login",   
            cancelButtonText: "Activate",   
            closeOnConfirm: false,   
            closeOnCancel: false 
        }, function(isConfirm){   
            if (isConfirm) { 
             window.location.href = "/";
               
            } else {     
                swal("Email Sent", "Please check your email for activation steps", "success");
                $('#rgstr input').val("");
            } 
        }); 
            
            //Verify Email      
          $.ajax({      
            url:"http://localhost:3000/verify/wmsg",
            method:"POST",
            data:{
            "first_name":fname,
            "last_name": lname,        
            "email": eml,
            "username": eml,
            "password": p,
            "university": uni,
            "country": country,    
            },
            success:function (data) {
            }, error: function (data) {
            alert("Error sending verified email");    
            console.log(data)
            }  
            }); //End    
                
          //Welcome Email      
          $.ajax({      
            url:"http://localhost:3000/uni/wmsg",
            method:"POST",
            data:{
            "first_name":fname,
            "last_name": lname,        
            "email": eml,
            "username": eml,
            "password": p,
            "university": uni,
            "country": country,    
            },
            success:function (data) {
            }, error: function (data) {
            console.log(data)
            alert("Email sending has an error");
            }  
            }); //End
           
             
                     
            }, error: function (data) {
            console.log(data)
            alert("Oops, Registration encountered an error");    
        }
    
    });  
                
                
            } else if (data.email) {
             //alert("User already exists with" + data.email)
             $(".usrem").show().css('color','red');
             $(".usrem small").html("User already exists with " + data.email);     
            } 
                
                
            }, error: function (data) {
            alert("Error Verifying user exists");    
            console.log(data)
            } //End error   
    
});//end uc
    
} 
   
if((!validateurl)) {
   swal("InValid", "Your website or url is invalid please make sure to add HTTP:// OR HTTPS://", "error"); 
}     
       
if((!validemail)) {
   swal("InValid Email", "Your email format is invalid", "error"); 
}     
  
if((!validterms)) {
   swal("Let's Agree", "You need to accept the terms and condition to be part of something great", "error"); 
} 

if((!validphone)) {
   swal("Invalid Phone Fromat", "We will need to call you to verify that students's can reach you also", "error"); 
} 
    
if ((!country)){ //Runs 1st ascending validation !important
  swal("Where are you located?", "You left your country field empty", "error"); 
    
}    
    
if ((!universityportal)){ //Runs 1st ascending validation !important
  swal("No Website?", "Seems like you left your application portal field empty", "error"); 
    
}      
    
if ((!ph)){ //Runs 1st ascending validation !important
  swal("Let's Keep intouch", "You need a phone number", "error"); 
    
}

if (minimump) {
  swal("Invalid Password Length", "Your password must be minimum 8 characters", "error");   
}    

if ((!p)){ //Runs 1st ascending validation !important
  swal("Security is needed", "Your password field is empty", "error"); 
    
}    
    
if ((!uni)){ //Runs 1st ascending validation !important
  swal("Are you existing?", "You left University Name field empty", "error"); 
    
}     
    
if ((!eml)){ //Runs 1st ascending validation !important
  swal("Oops", "You left Email field empty", "error"); 
    
}    
    
if ((!lname)){ //Runs 1st ascending validation !important
  swal("Oops", "You left Last Name field empty", "error"); 
    
}
    
if ((!fname)){ //Runs 1st ascending validation !important
  swal("Oops", "You left First Name field empty", "error"); 
    
}    

    
};  //End Apply 
  