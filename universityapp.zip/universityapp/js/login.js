
$(document).ready(function(){
 login ();        
});

// function to get announcement
function login () {

//var userid = "testid001";
//url = "https://www.yourdomain.com/sites/testfile/publichtml"+"/api/web('"+userid+"')/items"; //if this does not work add var before the string "url"

    
  var url = "http://localhost:3000/universities"    
    
    $.ajax({
        
            url:url,
            method:"GET",
            headers:{"Accept":"application/json; odata=verbose"},
            success: function (data) {
            console.log(data)       
            
            var entereduseremail = "country";  
            var setemailtolowercase = entereduseremail.toLowerCase()   
            
            
            $.each(data, function(key, value){
                
            if ( (value.email) == "naila@studyinbudapest.com") {
                alert (" Found it")
                return false;  
            } else {
                
                alert (" didn't find it");
            } 
                
            });
            
            
            
            
            
           
           /* if ( (data).indexOf(setemailtolowercase) > -1) {
                
                alert ("User Found")
                alert (entereduseremail)
                
            } else if (   !(   (data).indexOf(setemailtolowercase)> -1  )  ) {
                
                alert ("User not found")
                
            } */
            
            
                
            
        }, error: function (data) {
            console.log(data)
            alert("Oops, something went wrong,Could not retrieve data from server,please check your internet connection and try again");
        }
        

        
        
    });
    


}; //*/