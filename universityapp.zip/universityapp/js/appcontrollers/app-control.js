
    var myApp = angular.module('myApp'); //Extension of myApp

    myApp.filter('reverse', function() {
      return function(items) {
      if (!items || !items.length) { return; }
        return items.slice().reverse();
      };
    });

     //---------------END-----------------// 

    myApp.controller('studentsController',['$scope', '$http', '$location', '$routeParams','$anchorScroll','$templateCache', function($scope, $http, $location,  $routeParams, $anchorScroll, $templateCache){
   
       //$templateCache.removeAll();    
          
       $scope.authenticate = function(){    
           
       $http.get('http://localhost:3000/authentication').then(function(response){ 
        if (!response.data._id){    
          window.location.href = "/";  
        } else {   
        //Auth
        } 

       if ((response.data.activation) == "notactivated") {
            swal({   
                title: "Not Activated",   
                text: "We will like to make sure that you are a university we will send an email to " + response.data.email + " and give you a call at " + response.data.phone +" You can start using your account, as soon as we finish our verification. Be sure, we'll be in touch soon, In the mean time, should you have need to speak to us or if your information is taking longer than usual to be verified, please contact support: 1 (201) 992-1664",
                //imageUrl: "../plugins/images/users/avatar-student.png",
                type: "warning",   
                showCancelButton: false,   
                confirmButtonColor: "#DD6B55",   
                confirmButtonText: "Logout",   
                cancelButtonText: "Activate",
                allowEscapeKey: false,
                closeOnConfirm: false,   
                closeOnCancel: false 
            }, function(isConfirm){   
                if (isConfirm) { 
                 window.location.href = "logout";    
                } else {     

                } 
            });   

        } 
           
        //IF Trial Period   
        var trial = response.data.trial;//bool
        $scope.trial = trial;
       
        if ((trial) == true) {
        $scope.pbtn = true;
        } else {  

        //Reinitialize to default    
        var trial = response.data.trial;//bool

        } // End Trial Plan   
           
        var accountstatus = response.data.pd;   
        if ((accountstatus) == "free") {

        $("#free-upgrd-txt").html("Your Plan").removeClass('bg-info').addClass('bg-success');
        $("#startup-upgrd-txt").html("Upgrade");
        $("#prenmium-upgrd-txt").html("Upgrade");
        $("#advanced-upgrd-txt").html("Upgrade");
    
        $scope.index = 3;
        $scope.manageindex = 20;    
        $scope.freePlanButton = false; //hide    
        $scope.hideContact = true; //Yes //Show block
        $scope.viewContact = false; //No   
        $scope.Upgrade = true; //Show   
        $scope.downGrade = false;// Hide
        $scope.export = false; // disable
        $scope.freeplan= true;
        $scope.startuplan= false;
        $scope.prenmiumplan= false;    
        $scope.advancedplan = false;

        } else {  

        //Reinitialize to default    
        var accountstatus = response.data.pd;

        } // End Free Plan

        //Startup Plan    
        if ((accountstatus) == "startup") {
        $("#free-upgrd-txt").html("Choose");
        $("#startup-upgrd-txt").html("Your Plan").removeClass('bg-info').addClass('bg-success');;
        $("#prenmium-upgrd-txt").html("Upgrade");
        $("#advanced-upgrd-txt").html("Upgrade");    
        $scope.index = 5;
        $scope.manageindex = 1000;    
        $scope.freePlanButton = true;    
        $scope.hideContact = true; //Yes    
        $scope.viewContact = false; //No
        $scope.Upgrade = true; // Show
        $scope.downGrade = false; // Hide
        $scope.export = false; // disable
        $scope.freeplan= false;
        $scope.startuplan= true;
        $scope.prenmiumplan= false;     
        $scope.advancedplan = false;

        }
        else {  
        //Reinitialize to default     
        var accountstatus = response.data.pd;

        } // End 


        // Premium Plan
        if ((accountstatus) == "prenmium") { 
        $("#prenmium-upgrd-txt").html("Your Plan").removeClass('bg-info').addClass('bg-success');
        $("#startup-upgrd-txt").html("Upgrade");
        $("#free-upgrd-txt").html("Choose");
        $("#advanced-upgrd-txt").html("Upgrade");    
        $scope.Upgrade = true;    
        $scope.freePlanButton = true;    
        $scope.hideContact = false; //No 
        $scope.viewContact = true;  // Yes   
        $scope.Upgrade = true; //Show   
        $scope.downGrade = false; // Hide
        $scope.export = false; // disable
        $scope.freeplan= false;
        $scope.startuplan= false;
        $scope.prenmiumplan= true;     
        $scope.advancedplan = false;      
        //$scope.$apply();    
        } else {  
        //Reinitialize to default     
        var accountstatus = response.data.pd;

        } // End 



        // Advanced Plan
        if ((accountstatus) == "advanced") { 
        //You can do all these below
        $("#advanced-upgrd-txt").html("Your Plan").removeClass('bg-info').addClass('bg-success');
        $("#startup-upgrd-txt").html("Upgrade");
        $("#free-upgrd-txt").html("Choose");
        $("#prenmium-upgrd-txt").html("Upgrade");    
        $scope.freePlanButton = true;  //Pricing button  
        $scope.hideContact = false; //No  
        $scope.viewContact = true; // Yes
        $scope.Upgrade = false; // Hide
        $scope.downGrade = true; // Show
        $scope.export = true; // Show
        $scope.freeplan= false;
        $scope.startuplan= false;
        $scope.prenmiumplan= false; 
        $scope.advancedplan = true;    

        } else {  
        //Reinitialize to default     
        var accountstatus = response.data.pd;

        } // End    

        },function onError(response) {
            $scope.errormsg = response.statusText;
            //window.location.href = "500.html";
        }); 


        }//End Authenticate


        //---------------END-----------------// 

       //Activate
       $scope.activate = function(){
       var useremail = $routeParams.email;
       var activationurl = "http://localhost:3000/activate/" + useremail 
       $http.post(activationurl).then(function(response){ 
         if ((response.data.status) == "usernotfound"){    
          swal("Oops!", "This link has expired or your account no longer exists", "error");     
        } else if (response.data.email) {    
          window.location.href = "#/verified"    
        } 

        },function onError(response) {
            $scope.errormsg = response.statusText;
            //window.location.href = "500.html";
        });  

        }


       $scope.rp = function(){       
       var useremail = $("#rp").val();
       var rpurl = "http://localhost:3000/reset"
       var data = { "useremail": useremail }

        $http({
            method : "POST",
            url : rpurl,
            data: data
        }).then(function(response){ 

         if ((response.data.status) == "usernotfound"){    
        swal("Oops!", "We could not find the user with this email address", "error");     
        } else if (response.data.email) {    
        swal("Email Sent", "Password instructions has been sent to the email address: " + response.data.email, "success");    
        } 

        },function onError(response) {
            //console.log(response)
            $scope.errormsg = response.statusText;
            //window.location.href = "500.html";
        });  


        }

       //Get students
       $scope.getStudents = function (){
        $http.get('http://localhost:3000/students').then(function(response){
            $("#ntn-nw").hide();
            $(".n-aplctn-fd").hide();
            //$(".mng-std-tbl-hd").show();//Jquerize
            $scope.tblhead = true; //Angularize   
            $scope.students = response.data;
            var appliedstudents = $scope.aplctnrcvd = response.data.length;
            //var appliedstudents = $scope.aplctnrcvd = 1000000;// For testing max numbers    
            /**/if (appliedstudents >= 999999){
              $scope.aplctnrcvd = "1M+";
              //.substring(0, 5) + "-"  //For ... replacement   
            }
            $scope.notification = "Student application recieved";
            //console.log(response.data);
           /* angular.forEach(response.data, function(value, key) {
            var newDate = JSON.stringify(value.create_date)
            var dateStr = JSON.parse(newDate); //Convert to JS date object
            //console.log(dateStr); // 2014-01-01T23:28:56.782Z
            //Convert the date to Normal readable date
            var date = Date(dateStr); //use JS object to convert
            //console.log(date); 
             }); *///End Each

        }); //on error redirect to custom 404 server not reacheable, retry, redirect back to index   
      }
       //---------------END-----------------//  

       $scope.getStudent = function (){
        var id = $routeParams.id;   
        $http.get('http://localhost:3000/students/'+ id).then(function(response){
            $scope.student = response.data;
            //console.log(response.data);
            var accountstatus = $(".profile").attr('p');
            if (accountstatus == "startup"){
              $scope.studentemail = "";  
            } else if (accountstatus == "free"){
              $scope.studentemail = "";  
            } else {
                $scope.studentemail = response.data.email; 
            }
            
        });    
      } 

      //---------------END-----------------// 
       


      
    $scope.getUniversity = function (){
        //Initialize
        $scope.processedApplication = "0";
        $scope.admissionOffers ="0";    
        //var url = 'http://www.site.com/234234234';
        //var id = url.substring(url.lastIndexOf('/') + 1);
        //alert(id); // 234234234 
        //OR
        var id = $routeParams.id; 
        $http.get('http://localhost:3000/universities/'+ id).then(function(response){
            $scope.university = response.data;
            $(".sgdot").hide(); //Signed Out
            
    var profileavatar = response.data.first_name;
    $scope.avatarletter =  profileavatar.charAt(0);      
            
    var proccessedstudents = $scope.processedApplication = response.data.processed_students.length;
    //var proccessedstudents = $scope.processedApplication = 1000000;// For testing max numbers ;    
            if (proccessedstudents >= 999999){
              $scope.processedApplication = "1M+";
              //.substring(0, 5) + "-"  //For ... replacement   
            }
   var admissionoffers =  $scope.admissionOffers = response.data.admission_offers.length;
  //var admissionoffers =  $scope.admissionOffers = 1000000;// For testing max numbers ;    
            if (admissionoffers >= 999999){
              $scope.admissionOffers = "1M+";
              //.substring(0, 5) + "-"  //For ... replacement   
            }       
   var sumapplicants =  $scope.allapplctns = response.data.admission_offers.length + response.data.processed_students.length;      
    //var sumapplicants =  $scope.allapplctns = 1000000;// For testing max numbers ;  
            if (sumapplicants >= 999999){
              $scope.allapplctns = "1M+";
              //.substring(0, 5) + "-"  //For ... replacement   
            }        
            
        },function myError(response) {
            $scope.errormsg = response.statusText;
            //window.location.href = "500.html";
        }); 

          }   
     //---------------END-----------------// 

//Student Profile Page   
    $scope.getUniversitynStudents = function (){
        $scope.processedApplication = "0";
        $scope.admissionOffers ="0";    
        //var id = $routeParams.id;
       // $http.get('http://localhost:3000/authentication').then(function(response){
       // var id = response.data._id;
        var url = document.location.href;
        var uid = url.substring(url.lastIndexOf('/') - 24);
        var length = 24;
        var id = uid.substring(0, length);    
        $http.get('http://localhost:3000/universities/'+ id).then(function(response){
            $scope.university = response.data;
            var profileavatar = response.data.first_name;
            $scope.avatarletter =  profileavatar.charAt(0);
            $(".sgdot").hide();
        var proccessedstudents = $scope.processedApplication = response.data.processed_students.length;
        //var proccessedstudents = $scope.processedApplication = 1000000;// For testing max numbers ;    
            if (proccessedstudents >= 999999){
              $scope.processedApplication = "1M+";
              //.substring(0, 5) + "-"  //For ... replacement   
            }
        var admissionoffers =  $scope.admissionOffers = response.data.admission_offers.length;
        //var admissionoffers =  $scope.admissionOffers = 1000000;// For testing max numbers ;    
            if (admissionoffers >= 999999){
              $scope.admissionOffers = "1M+";
              //.substring(0, 5) + "-"  //For ... replacement   
            }
            $scope.allapplctns = response.data.admission_offers.length + response.data.processed_students.length;
            //console.log(response.data);

        },function myError(response) {
            $scope.errormsg = response.statusText;
            //console.log(response)
            //window.location.href = "500.html";
        });   
          //  });   
          } //End
     //---------------END-----------------// 
    
   
     //Processed Table Rows
     $scope.getRcrtdStudentPrfl = function (){
        var id = $routeParams.id;  
        $http.get('http://localhost:3000/recruited/universities/'+ id).then(function(response){
            $scope.uninstd = response.data.admission_offers; //Recruited
            $scope.msgstd = response.data.processed_students; //Messaged
            //console.log(response.data);                   
        });    
      } 
     //---------------END-----------------// 

    }]);//End Controller

   /* myApp.controller('pricingController',['$scope', '$http', '$location', '$routeParams','$anchorScroll', function($scope, $http, $location,  $routeParams, $anchorScroll){

    }]);//End Controller*/

    /* 
    $scope.$on('$routeChangeSuccess', function () {
    //console.log('Route Changed');        
    });
     //---------------END-----------------// 
     */